/****************************************************/
/* Library Directives							    */
/****************************************************/
///**#include"../Include/LIB/STD_TYPES.h"

#include"../Include/LIB/BIT_MATH.h"
#include"../Include/LIB/STD_TYPES.h"
#include <util/delay.h>
/****************************************************/
/* DIO Directives								    */
/****************************************************/

#include"../Include/MCAL/DIO/DIO_Interface.h"
#include"../Include/MCAL/DIO/DIO_Private.h"
#include"../Include/MCAL/DIO/DIO_Configuration.h"

/****************************************************/
/* LCD Directives								    */
/****************************************************/

#include"../Include/HAL/LCD/LCD_Interface.h"
#include"../Include/HAL/LCD/LCD_Private.h"
#include"../Include/HAL/LCD/LCD_Configuraion.h"

/****************************************************/
/* KEYPAD Directives								    */
/****************************************************/

#include"../Include/HAL/KEYPAD/KEYPAD_Interface.h"
#include"../Include/HAL/KEYPAD/KEYPAD_Private.h"
#include"../Include/HAL/KEYPAD/KEYPAD__Configuration.h"

/*
u8 Global_u8Arr[]={
	  0x0A,
	  0x15,
	  0x11,
	  0x11,
	  0x0A,
	  0x04,
	  0x1F,
	  0x00
};*/

u8 StickMan1[] = {
		  0x1C,
		  0x1C,
		  0x08,
		  0x1C,
		  0x08,
		  0x08,
		  0x14,
		  0x14
};


u8 BOX[] = {
		  0x0E,
		  0x0E,
		  0x1F,
		  0x00,
		  0x00,
		  0x00,
		  0x00,
		  0x00
};

u8 StickMan2[] = {
		  0x00,
		  0x1C,
		  0x1C,
		  0x0B,
		  0x0C,
		  0x08,
		  0x14,
		  0x14
};


u8 double_men[] = {
		  0x00,
		  0x1F,
		  0x1F,
		  0x0A,
		  0x1F,
		  0x0A,
		  0x15,
		  0x15
};

u8 bullet[] = {

  0x00,
  0x00,
  0x0C,
  0x0C,
  0x00,
  0x00,
  0x00,
  0x00
};

u8 The_dead_one[]={
		0x00,
		0x00,
		0x00,
		0x00,
        0x13,
		0x0F,
		0x13,
		0x00
};

void main (void)
{
	MDIO_voidInit();
	HLCD_voidInit();
	_delay_ms(20);



	/*
	/* Stick Man 1 .. walking*/
	for(u8 i = 0 ; i < 16 ; i++){
	_delay_ms(1000);
	HLCD_voidClearDisplay ();
    HLCD_voidGoToPos(LCD_u8_LINE1,i+1);
	LCD_voidSendSpecialCharacter(StickMan1, i, LCD_u8_LINE1, i+1);
	}


	/* the other with Gun appear*/

	LCD_voidSendSpecialCharacter(StickMan2, 1, LCD_u8_LINE1, 1);
	LCD_voidSendSpecialCharacter( bullet, 2, LCD_u8_LINE1, 2);


	/* surprise*/
	HLCD_voidGoToPos(LCD_u8_LINE2,1);
	_delay_ms(2000);
	HLCD_voidSendString("  Oooh Oooh !! ");
	_delay_ms(2000);




	for(u8 i = 2 ; i < 15 ; i++){

	_delay_ms(2000);
	HLCD_voidClearDisplay ();
    //LCD_voidSendSpecialCharacter(bullet_clear, 2, LCD_u8_LINE1, i);
	HLCD_voidGoToPos(LCD_u8_LINE1,16);
	LCD_voidSendSpecialCharacter(StickMan1, 0, LCD_u8_LINE1, 16);
	HLCD_voidGoToPos(LCD_u8_LINE1,1);
	LCD_voidSendSpecialCharacter(StickMan2, 1, LCD_u8_LINE1, 1);
	HLCD_voidGoToPos(LCD_u8_LINE1,i+1);
	LCD_voidSendSpecialCharacter(bullet, 2, LCD_u8_LINE1, i+2);
	}

	LCD_voidSendSpecialCharacter(The_dead_one, 3, LCD_u8_LINE1, 16);
	HLCD_voidGoToPos(LCD_u8_LINE2,5);
	HLCD_voidSendString("_ RIP _");



	_delay_ms(2000);

	HLCD_voidClearDisplay ();
	HLCD_voidGoToPos(LCD_u8_LINE2,7);
	LCD_voidSendSpecialCharacter(StickMan1, 0, LCD_u8_LINE1, 7);
	_delay_ms(2000);
	LCD_voidSendSpecialCharacter(StickMan1, 1, LCD_u8_LINE1, 8);
	_delay_ms(2000);
	LCD_voidSendSpecialCharacter(StickMan1, 3, LCD_u8_LINE1, 9);
	_delay_ms(2000);
	LCD_voidSendSpecialCharacter(StickMan1, 4, LCD_u8_LINE1, 10);
	_delay_ms(3000);
	HLCD_voidClearDisplay ();

	_delay_ms(1000);
	LCD_voidSendSpecialCharacter(double_men, 0, LCD_u8_LINE2, 7);
	_delay_ms(1000);
	LCD_voidSendSpecialCharacter(double_men, 1, LCD_u8_LINE2, 9);
	_delay_ms(1000);
	LCD_voidSendSpecialCharacter(BOX, 5, LCD_u8_LINE2, 8);

	/*THE DANCE */

	for(u8 i = 0 ; i < 4 ; i++){
	_delay_ms(3000);
	HLCD_voidClearDisplay ();
	HLCD_voidGoToPos(LCD_u8_LINE2,6);
	LCD_voidSendSpecialCharacter(double_men, 0, LCD_u8_LINE2, 6);
    LCD_voidSendSpecialCharacter(double_men, 1, LCD_u8_LINE2, 8);
    LCD_voidSendSpecialCharacter(BOX, 5, LCD_u8_LINE2, 7);
    _delay_ms(3000);
    HLCD_voidClearDisplay ();
    HLCD_voidGoToPos(LCD_u8_LINE2,9);
	LCD_voidSendSpecialCharacter(double_men, 0, LCD_u8_LINE2, 8);
    LCD_voidSendSpecialCharacter(double_men, 1, LCD_u8_LINE2, 10);
    LCD_voidSendSpecialCharacter(BOX, 5, LCD_u8_LINE2, 9);

	}


	while(1);
}



