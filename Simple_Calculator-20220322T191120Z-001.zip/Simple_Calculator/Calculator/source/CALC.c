/*
 * CALC.c
 *
 *  Created on: ??�/??�/????
 *      Author: Meriam
 */


#include <util/delay.h>
/*************** Library Directives ***************/

#include"../Includes/LIB/STD_types.h"
#include"../Includes/LIB/Bit_Math.h"

/***************** DIO Directives ****************/

#include"../Includes/MCAL/DIO/DIO_Interface.h"
#include"../Includes/MCAL/DIO/DIO_Private.h"
#include"../Includes/MCAL/DIO/DIO_Configuration.h"

/* LCD Directives								    */
/****************************************************/
#include"../Includes/HAL/LCD/LCD_Interface.h"
#include"../Includes/HAL/LCD/LCD_Private.h"
#include"../Includes/HAL/LCD/LCD_Configuraion.h"

/* KEYPAD Directives								    */
/****************************************************/
#include "../Includes/HAL/KEYPAD/KEYPAD_Interface.h"
#include "../Includes/HAL/KEYPAD/KEYPAD_Private.h"
#include "../Includes/HAL/KEYPAD/KEYPAD__Configuration.h"


/*______________________________________________________________________________________________________________________*/


u8 get_key(void){

	u8 value;
	while(1){
		value=HKEYPAD_u8_GetPressedKey();
		if (value != 0xFF){
			HLCD_voidSendData(value);
			break;
		}
	}
	return value;
}


u8 func(void ){

	u8 in_KeyValue = get_key();

	u8 VAL ;
	in_KeyValue = in_KeyValue - 48 ;

if ((in_KeyValue >= 0) && (in_KeyValue < 10)){

     VAL = in_KeyValue ;
     //HLCD_voidDisplayNumber(VAL);
	}

else {

	in_KeyValue = in_KeyValue + 48 ;

if ((in_KeyValue == '-') || (in_KeyValue == '+')|| (in_KeyValue == '*')|| (in_KeyValue == '/')){

	VAL = in_KeyValue ;
}
else if (in_KeyValue == 'c'){

	HLCD_voidClearDisplay ();
	VAL = ' ';
}

}
return VAL ;

}


