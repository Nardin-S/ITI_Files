/*
 * main.c
 *
 *  Created on: ??�/??�/????
 *      Author: Meriam
 */

#include <util/delay.h>
/*************** Library Directives ***************/

#include"../Includes/LIB/STD_types.h"
#include"../Includes/LIB/Bit_Math.h"

/***************** DIO Directives ****************/

#include"../Includes/MCAL/DIO/DIO_Interface.h"
#include"../Includes/MCAL/DIO/DIO_Private.h"
#include"../Includes/MCAL/DIO/DIO_Configuration.h"

/* LCD Directives								    */
/****************************************************/
#include"../Includes/HAL/LCD/LCD_Interface.h"
#include"../Includes/HAL/LCD/LCD_Private.h"
#include"../Includes/HAL/LCD/LCD_Configuraion.h"

/* KEYPAD Directives								    */
/****************************************************/
#include "../Includes/HAL/KEYPAD/KEYPAD_Interface.h"
#include "../Includes/HAL/KEYPAD/KEYPAD_Private.h"
#include "../Includes/HAL/KEYPAD/KEYPAD__Configuration.h"


/*______________________________________________________________________________________________________________________*/


void main(void) {

	MDIO_voidSetPortDirection (DIO_u8_PORTA, DIO_u8_PORT_OUTPUT);

	MDIO_voidSetPinDIrection (DIO_u8_PORTB ,  LCD_E_PIN , DIO_u8_INITIAL_OUTPUT);
	MDIO_voidSetPinDIrection (DIO_u8_PORTB ,  LCD_RS_PIN, DIO_u8_INITIAL_OUTPUT);
	MDIO_voidSetPinDIrection (DIO_u8_PORTB ,  LCD_RW_PIN ,DIO_u8_INITIAL_OUTPUT);

	HLCD_voidInit();
	Keypad_Init();

	u8 NUM1 , NUM2 , OP , Equal , Res;

	//u8 NUM = 255 ;

	/*u8 num = '5';
	num = num - 48 ;
	num += 1 ;
	//HLCD_voidSendString ("hello!");
	//HLCD_voidDisplayNumber(num);
	//u8 val = HKEYPAD_u8_GetPressedKey();*/

	while(1){

	/**	if (local_u8KeypadValue != KEYPAD_u8_KEY_NOT_PRESSED)  // !(0xff)
				{
					HLCD_voidSendData(local_u8KeypadValue);
				}***/
		NUM1 =func();
		if(NUM1 == ' '){
			NUM1 = 0 ;
			NUM2 = 0;
			continue;
		}
		//_delay_ms(10);
		OP =func();
		//_delay_ms(10);
		if(OP == ' '){
			NUM1 = 0 ;
			NUM2 = 0;
			continue;
		}

		NUM2 =func();
		if(NUM2 == ' '){
			NUM1 = 0 ;
			NUM2 = 0;
			continue;
		}
		//_delay_ms(10);

		Equal = get_key();
		if(Equal == ' '){
			NUM1 = 0 ;
			NUM2 = 0;
			continue;
		}

		if( Equal == '='){
		switch(OP) {
			case '*' :
				Res = NUM1  * NUM2 ;
				HLCD_voidDisplayNumber(Res);
				break;

			case '/' :
				Res = NUM1 / NUM2 ;
				if(NUM2 == 0){
					HLCD_voidClearDisplay ();
					HLCD_voidSendString ("Math Error!!");
				}
				else {
				HLCD_voidDisplayNumber(Res);
				}
				break;

			case '+' :
				Res = NUM1 + NUM2 ;
				HLCD_voidDisplayNumber(Res);
				break;

			case '-' :
				Res = NUM1 - NUM2;
				if (NUM1 < NUM2){
					HLCD_voidSendData('-');
					HLCD_voidDisplayNumber(256 - Res);
				}
				else{
				HLCD_voidDisplayNumber(Res);
				}
				break;
			}}

	}}
/*

		_delay_ms(10);
	}
	return;
	}
***/




