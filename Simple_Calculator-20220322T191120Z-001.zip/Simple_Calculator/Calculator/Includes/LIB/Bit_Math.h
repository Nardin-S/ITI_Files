#ifndef BIT_MATH_H_
#define BIT_MATH_H_

#define SetBit(reg,n_bit)     (reg |= (1<<n_bit))
#define ClearBit(reg,n_bit)   (reg &= ~(1<<n_bit))
#define ToggleBit(reg,n_bit)  (reg ^= (1<<n_bit))
#define GetBit(reg,n_bit)     ((reg>>n_bit)&0x01)
#define SetByte(reg ,value)   (reg = value )


#define CONC_BIT(b7,b6,b5,b4,b3,b2,b1,b0)       Conc_Help(b7,b6,b5,b4,b3,b2,b1,b0)
#define Conc_Help(b7,b6,b5,b4,b3,b2,b1,b0)      0b##b7##b6##b5##b4##b3##b2##b1##b0


#endif

