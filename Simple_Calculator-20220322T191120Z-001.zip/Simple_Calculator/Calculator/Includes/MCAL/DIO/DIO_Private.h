/*
 * DIO_Private.h
 *
 *  Created on: ??�/??�/????
 *      Author: Meriam
 */

#ifndef INCLUDE_MCAL_DIO_DIO_PRIVATE_H_
#define INCLUDE_MCAL_DIO_DIO_PRIVATE_H_


/************ PORT A Register Mapping *************************/
#define DIO_u8_PORTA_Reg        *((volatile u8 *)0x3B)
#define DIO_u8_DDRA_Reg         *((volatile u8 *)0x3A)
#define DIO_u8_PINA_Reg         *((volatile u8 *)0x39)

/************ PORT B Register Mapping *************************/
#define DIO_u8_PORTB_Reg        *((volatile u8 *)0x38)
#define DIO_u8_DDRB_Reg         *((volatile u8 *)0x37)
#define DIO_u8_PINB_Reg         *((volatile u8 *)0x36)

/************ PORT C Register Mapping *************************/
#define DIO_u8_PORTC_Reg        *((volatile u8 *)0x35)
#define DIO_u8_DDRC_Reg         *((volatile u8 *)0x34)
#define DIO_u8_PINC_Reg         *((volatile u8 *)0x33)

/************ PORT D Register Mapping *************************/
#define DIO_u8_PORTD_Reg        *((volatile u8 *)0x32)
#define DIO_u8_DDRD_Reg         *((volatile u8 *)0x31)
#define DIO_u8_PIND_Reg         *((volatile u8 *)0x30)

/**************************************************************/

/**  Set Direction **/
#define DIO_u8_INITIAL_OUTPUT           1       /* DIO_PIN_OUTPUT*/
#define DIO_u8_INITIAL_INPUT            0       /* DIO_PIN_INPUT*/

/***_initializing PORTS Directions_ **
#define DIO_u8_PORT_INITIAL_OUTPUT      0xFF
#define DIO_u8_PORT_INITIAL_OUTPUT      0*/

/* Set Pins initial values */

#define DIO_u8_OUTPUT_HIGH         1
#define DIO_u8_OUTPUT_LOW          0

#define DIO_u8_INPUT_PULLUP        1
#define DIO_u8_INPUT_FLOATING      0


/**_initializing PORTS Values_*
#define DIO_u8_PORT_HIGH         0xFF
#define DIO-u8_PORT_LOW          0*/


#endif /* INCLUDE_MCAL_DIO_DIO_PRIVATE_H_ */
