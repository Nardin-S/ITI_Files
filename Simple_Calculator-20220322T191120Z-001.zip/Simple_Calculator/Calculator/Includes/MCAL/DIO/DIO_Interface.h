/*
 * DIO_Interface.h
 *
 *  Created on: ??�/??�/????
 *      Author: Meriam
 */

#ifndef INCLUDE_MCAL_DIO_DIO_INTERFACE_H_
#define INCLUDE_MCAL_DIO_DIO_INTERFACE_H_


#define DIO_u8_PORTA  0
#define DIO_u8_PORTB  1
#define DIO_u8_PORTC  2
#define DIO_u8_PORTD  3

#define DIO_u8_PIN0   0
#define DIO_u8_PIN1   1
#define DIO_u8_PIN2   2
#define DIO_u8_PIN3   3
#define DIO_u8_PIN4   4
#define DIO_u8_PIN5   5
#define DIO_u8_PIN6   6
#define DIO_u8_PIN7   7

/*** PORTS ***/
#define DIO_u8_PORT_OUTPUT      0xFF
#define DIO_u8_PORT_INPUT       0

#define DIO_u8_PORT_HIGH        0xFF
#define DIO_u8_PORT_LOW         0x00

/*** PINS  ***/
#define DIO_u8_OUTPUT 1
#define DIO_u8_INPUT  0

#define DIO_u8_HIGH   1
#define DIO_u8_LOW    0
/************************

/*----------------------------------------------------------------------------*/
/* Function: MDIO_voidInit			                        				  */
/* I/P Parameters: No thing									          		  */
/* Returns:it returns No thing                                				  */
/* Desc:This Function Set the initial direction & value of All pins           */
/*------------------------------------------------------------------------------*/
void MDIO_voidInit(void);



/*----------------------------------------------------------------------------*
* Function: Set_Pin_Direction			                        			  *
* I/P Parameters: * PORTID : PORTA , PORTB, PORTC , PORTD                     *
                  * PINID  : FROM PIN0 -->	PIN7                              *
                  * Pin Directon : DIO_u8_OUTPUT , DIO_u8_INPUT				  *
* Returns:it returns No thing                                				  *
* Desc:This Function Set the direction of a given pin                         *
------------------------------------------------------------------------------*/
void MDIO_voidSetPinDIrection(u8 copy_u8PORTID , u8 copy_u8PINID , u8 copy_u8PinDirection);



/*----------------------------------------------------------------------------*
* Function: Set_Pin_Value			                        			      *
* I/P Parameters: * PORTID : PORTA , PORTB, PORTC , PORTD                     *
                  * PINID  : FROM PIN0 -->	PIN7                              *
                  * Pin Directon : DIO_u8_HIGH , DIO_u8_LOW			          *
* Returns:it returns No thing                                				  *
* Desc:This Function Set Pin Value                                            *
------------------------------------------------------------------------------*/
void MDIO_voidSetPinValue (u8 copy_u8PORTID , u8 copy_u8PINID , u8 copy_u8PinValue);


/*----------------------------------------------------------------------------*
* Function: Get_Pin_Value			                        			      *
* I/P Parameters: * PORTID : PORTA , PORTB, PORTC , PORTD                     *
                  * PINID  : FROM PIN0 -->	PIN7                              *
* Returns:it returns Pin Value                                				  *
* Desc:This Function Gets the Value of a given pin	                          *
------------------------------------------------------------------------------*/
u8 MDIO_u8Get_Pin_Value (u8 copy_u8PORTID , u8 copy_u8PINID );

/*----------------------------------------------------------------------------*
* Function: Set_Port_Direction			                        			  *
* I/P Parameters: * PORTID : PORTA , PORTB, PORTC , PORTD                     *
                  * PortDirection : DIO_u8_PORT_OUTPUT , DIO_u8_PORT_INPUT    *
                                   , OR the suitable hex value for port pins  *
* Returns:it returns Nothing                                				  *
* Desc:This Function Set Port Direction	                                      *
------------------------------------------------------------------------------*/
void MDIO_voidSetPortDirection (u8 copy_u8PortID, u8 copy_u8PortDirection);


/*----------------------------------------------------------------------------*
* Function: Set Port Value			                        			      *
* I/P Parameters: * PORTID : PORTA , PORTB, PORTC , PORTD                     *
                  * PortDirection :  DIO_u8_PORT_HIGH , DIO_u8_PORT_LOW       *
                                   , OR the suitable hex value for port pins  *
* Returns:it returns Nothing                                				  *
* Desc:This Function Set Port Value	                          *
------------------------------------------------------------------------------*/
void MDIO_voidSetPortValue (u8 copy_u8PortID, u8 copy_u8PortValue);




#endif /* INCLUDE_MCAL_DIO_DIO_INTERFACE_H_ */
