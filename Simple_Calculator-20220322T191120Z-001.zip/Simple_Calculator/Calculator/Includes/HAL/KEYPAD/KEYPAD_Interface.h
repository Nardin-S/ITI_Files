/*
 * KEYPAD_Interface.h
 *
 *  Created on: ??�/??�/????
 *      Author: Meriam
 */

#ifndef INCLUDE_HAL_KEYPAD_KEYPAD_INTERFACE_H_
#define INCLUDE_HAL_KEYPAD_KEYPAD_INTERFACE_H_

void Keypad_Init(void);
u8 HKEYPAD_u8_GetPressedKey (void);
u8 SIMPLE_CALC(u8 localVariable);
u8 func(void );
u8 get_key(void);

#endif /* INCLUDE_HAL_KEYPAD_KEYPAD_INTERFACE_H_ */
