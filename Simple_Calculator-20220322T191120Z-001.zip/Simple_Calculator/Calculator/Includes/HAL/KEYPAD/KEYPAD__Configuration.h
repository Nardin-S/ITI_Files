/*
 * KEYPAD__Configuration.h
 *
 *  Created on: ??�/??�/????
 *      Author: Meriam
 */

#ifndef INCLUDE_HAL_KEYPAD_KEYPAD__CONFIGURATION_H_
#define INCLUDE_HAL_KEYPAD_KEYPAD__CONFIGURATION_H_

#define KEYPAD_u8_PORT     DIO_u8_PORTC


#define KEYPAD_ROW_1       DIO_u8_PIN0
#define KEYPAD_ROW_2       DIO_u8_PIN1
#define KEYPAD_ROW_3       DIO_u8_PIN2
#define KEYPAD_ROW_4       DIO_u8_PIN3

#define KEYPAD_COL_1       DIO_u8_PIN4
#define KEYPAD_COL_2       DIO_u8_PIN5
#define KEYPAD_COL_3       DIO_u8_PIN6
#define KEYPAD_COL_4       DIO_u8_PIN7


#define KEYPAD_u8_ROW_NUM      4
#define KEYPAD_u8_COL_NUM      4


#define KEYPAD_Au8_KEYS    {{'7','8','9','/'},\
	                        {'4','5','6','*'},\
							{'1','2','3','-'},\
							{'c','0','=','+'}}

#define KEYPAD_Au8ROWS     {KEYPAD_ROW_1 , KEYPAD_ROW_2 , KEYPAD_ROW_3 , KEYPAD_ROW_4 }
#define KEYPAD_Au8COLS     {KEYPAD_COL_1 , KEYPAD_COL_2 , KEYPAD_COL_3 , KEYPAD_COL_4 }


#define KEYPAD_u8_KEY_NOT_PRESSED      0xFF
#define KEYPAD_u8_DEBOUNCING_MS        20


#define KEYPAD_u8_FLAG_DOWN   0
#define KEYPAD_u8_FLAG_UP     1

#endif /* INCLUDE_HAL_KEYPAD_KEYPAD__CONFIGURATION_H_ */
