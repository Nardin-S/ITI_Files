/*
 * S7egment_Interface.h
 *
 *  Created on: ??�/??�/????
 *      Author: Meriam
 */

#ifndef INCLUDE_HAL_S7EGMENT_S7EGMENT_INTERFACE_H_
#define INCLUDE_HAL_S7EGMENT_S7EGMENT_INTERFACE_H_


void H7Segment_INIT (void);

void H7Segment_DisplayNum (u8 copy_u8Num);

void Segment_increment_Counter(u8 Count);

void Segment_decrement_Counter (u8 Count);



#endif /* INCLUDE_HAL_S7EGMENT_S7EGMENT_INTERFACE_H_ */
