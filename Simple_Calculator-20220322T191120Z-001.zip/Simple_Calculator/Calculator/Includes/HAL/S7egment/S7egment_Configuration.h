/*
 * S7egment_Configuration.h
 *
 *  Created on: ??�/??�/????
 *      Author: Meriam
 */

#ifndef INCLUDE_HAL_S7EGMENT_S7EGMENT_CONFIGURATION_H_
#define INCLUDE_HAL_S7EGMENT_S7EGMENT_CONFIGURATION_H_

#define CommonAnode_Cathode   0  //0 : cathode   1: Anode


#define PORT7SEG   DIO_u8_PORTC




#endif /* INCLUDE_HAL_S7EGMENT_S7EGMENT_CONFIGURATION_H_ */
