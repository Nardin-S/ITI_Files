/*
 * S7egment_Private.h
 *
 *  Created on: ??�/??�/????
 *      Author: Meriam
 */

#ifndef INCLUDE_HAL_S7EGMENT_S7EGMENT_PRIVATE_H_
#define INCLUDE_HAL_S7EGMENT_S7EGMENT_PRIVATE_H_

#if CommonAnode_Cathode == 1
/*For Common Anode*/
#define ZERO  0xC0
#define ONE   0xF9
#define TWO   0xA4
#define THREE 0xB0
#define FOUR  0x99
#define FIVE  0x92
#define SIX   0x82
#define SEVEN 0xF8
#define EIGHT 0x80
#define NINE  0x90


/*For Common Cathod*/
#elif CommonAnode_Cathode == 0
#define ZERO  0x3F
#define ONE   0x06
#define TWO   0x5B
#define THREE 0x4F
#define FOUR  0x66
#define FIVE  0x6D
#define SIX   0x7D
#define SEVEN 0x07
#define EIGHT 0x7F
#define NINE  0x6F

#endif

#endif /* INCLUDE_HAL_S7EGMENT_S7EGMENT_PRIVATE_H_ */
